/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.login;

/**
 *
 * @author juan fabra
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaPrincipal extends JFrame {
    private JPanel panelPrincipal;
    private JPanel panelLogin, panelCatalogo, panelCarrito, panelListaDeseos, panelCambioContraseña;
    private CardLayout cardLayout;
    private DefaultListModel<String> carritoModel;
    private DefaultListModel<String> listaDeseosModel;

    private String contraseñaGuardada = "1234"; // Contraseña por defecto para el login

    public VentanaPrincipal() {
        setTitle("Tienda Virtual - Vendedores");
        setSize(900, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Inicializa el panel principal con CardLayout
        cardLayout = new CardLayout();
        panelPrincipal = new JPanel(cardLayout);
        getContentPane().add(panelPrincipal);

        carritoModel = new DefaultListModel<>();
        listaDeseosModel = new DefaultListModel<>();

        // Inicializa los diferentes paneles
        inicializarLogin();  // Panel Login
        inicializarCatalogo();  // Panel Catálogo
        inicializarCarrito();  // Panel Carrito
        inicializarListaDeseos();  // Panel Lista de Deseos
        inicializarCambioContraseña(); // Panel para cambiar contraseña

        setVisible(true);
    }

    private void inicializarLogin() {
        panelLogin = new JPanel();
        panelLogin.setLayout(new GridBagLayout());
        panelLogin.setBackground(new Color(220, 230, 250)); // Fondo suave

        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setFont(new Font("Arial", Font.BOLD, 16));

        JTextField txtUsuario = new JTextField(15);

        JLabel lblContrasena = new JLabel("Contraseña:");
        lblContrasena.setFont(new Font("Arial", Font.BOLD, 16));

        JPasswordField txtContrasena = new JPasswordField(15);

        JButton btnLogin = new JButton("Iniciar Sesión");
        btnLogin.setFont(new Font("Arial", Font.BOLD, 14));
        btnLogin.setBackground(new Color(60, 179, 113)); // Verde claro
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);

        // Botón para ir a la sección de cambiar contraseña
        JButton btnCambiarContrasena = new JButton("Olvidé mi contraseña");
        btnCambiarContrasena.setFont(new Font("Arial", Font.PLAIN, 14));
        btnCambiarContrasena.setForeground(Color.RED);
        btnCambiarContrasena.addActionListener(e -> cardLayout.show(panelPrincipal, "CambioContraseña"));

        // Iniciar sesión
        btnLogin.addActionListener(e -> {
            String passwordInput = new String(txtContrasena.getPassword());
            if (passwordInput.equals(contraseñaGuardada)) {
                // Efecto visual: transición suave hacia el catálogo
                cardLayout.show(panelPrincipal, "Catalogo");
            } else {
                JOptionPane.showMessageDialog(this, "Contraseña incorrecta, intente nuevamente.");
            }
        });

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panelLogin.add(lblUsuario, gbc);
        gbc.gridx = 1;
        panelLogin.add(txtUsuario, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panelLogin.add(lblContrasena, gbc);
        gbc.gridx = 1;
        panelLogin.add(txtContrasena, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panelLogin.add(btnLogin, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panelLogin.add(btnCambiarContrasena, gbc);

        panelPrincipal.add(panelLogin, "Login");
    }

    private void inicializarCatalogo() {
        panelCatalogo = new JPanel();
        panelCatalogo.setLayout(new BorderLayout());
        panelCatalogo.setBackground(Color.WHITE);

        JLabel lblTitulo = new JLabel("Catálogo de Productos", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));

        JPanel panelProductos = new JPanel();
        panelProductos.setLayout(new GridLayout(3, 3, 15, 15));
        panelProductos.setBackground(Color.WHITE);

        // Lista de productos con nombre, descripción y precio
        String[][] productos = {
            {"Manzana", "Deliciosa manzana roja", "$2.00"},
            {"Pera", "Jugosa y dulce", "$2.50"},
            {"Jugo de naranja", "Natural y fresco", "$1.80"},
            {"Pan", "Esponjoso y recién horneado", "$1.00"},
            {"Leche", "Fresca y pasteurizada", "$1.50"},
            {"Café", "De grano colombiano", "$3.00"},
            {"Queso", "Suave y cremoso", "$2.70"},
            {"Té Verde", "Refrescante y antioxidante", "$1.60"}
        };

        // Mostrar los productos con precios
        for (String[] producto : productos) {
            JButton btnProducto = new JButton("<html><b>" + producto[0] + "</b><br>" + producto[1] + "<br><i>" + producto[2] + "</i></html>");
            btnProducto.setFont(new Font("Arial", Font.PLAIN, 14));
            btnProducto.setBackground(new Color(245, 245, 245)); // Gris claro
            btnProducto.setBorder(BorderFactory.createLineBorder(new Color(70, 130, 180), 2));
            btnProducto.addActionListener(e -> mostrarOpcionesProducto(producto[0], producto[2]));
            panelProductos.add(btnProducto);
        }

        JButton btnCarrito = new JButton("Ir al Carrito");
        JButton btnListaDeseos = new JButton("Ir a Lista de Deseos");

        estilizarBoton(btnCarrito, new Color(46, 139, 87)); // Verde oscuro
        estilizarBoton(btnListaDeseos, new Color(123, 104, 238)); // Morado suave

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnCarrito);
        panelBotones.add(btnListaDeseos);

        btnCarrito.addActionListener(e -> cardLayout.show(panelPrincipal, "Carrito"));
        btnListaDeseos.addActionListener(e -> cardLayout.show(panelPrincipal, "ListaDeseos"));

        panelCatalogo.add(lblTitulo, BorderLayout.NORTH);
        panelCatalogo.add(panelProductos, BorderLayout.CENTER);
        panelCatalogo.add(panelBotones, BorderLayout.SOUTH);

        panelPrincipal.add(panelCatalogo, "Catalogo");
    }

    private void mostrarOpcionesProducto(String producto, String precio) {
        int opcion = JOptionPane.showOptionDialog(
            this,
            "¿Qué desea hacer con " + producto + " (" + precio + ")?",
            "Opciones de Producto",
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            new String[]{"Agregar al Carrito", "Agregar a Lista de Deseos", "Cancelar"},
            "Cancelar"
        );

        switch (opcion) {
            case 0 -> carritoModel.addElement(producto + " - " + precio);
            case 1 -> listaDeseosModel.addElement(producto + " - " + precio);
        }
    }

    private void inicializarCarrito() {
        panelCarrito = new JPanel();
        panelCarrito.setLayout(new BorderLayout());
        panelCarrito.setBackground(Color.WHITE);

        JLabel lblTitulo = new JLabel("Carrito de Compras", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));

        JList<String> listaCarrito = new JList<>(carritoModel);
        JScrollPane scrollCarrito = new JScrollPane(listaCarrito);

        JButton btnFinalizarCompra = new JButton("Finalizar Compra");
        estilizarBoton(btnFinalizarCompra, new Color(34, 139, 34)); // Verde intenso

        JButton btnVolver = new JButton("Volver al Catálogo");
        estilizarBoton(btnVolver, new Color(70, 130, 180)); // Azul

        btnFinalizarCompra.addActionListener(e -> {
            if (!carritoModel.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Compra realizada. Llegará en 2 días.");
                carritoModel.clear();
            } else {
                JOptionPane.showMessageDialog(this, "El carrito está vacío.");
            }
        });

        btnVolver.addActionListener(e -> cardLayout.show(panelPrincipal, "Catalogo"));

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnFinalizarCompra);
        panelBotones.add(btnVolver);

        panelCarrito.add(lblTitulo, BorderLayout.NORTH);
        panelCarrito.add(scrollCarrito, BorderLayout.CENTER);
        panelCarrito.add(panelBotones, BorderLayout.SOUTH);

        panelPrincipal.add(panelCarrito, "Carrito");
    }

    private void inicializarListaDeseos() {
        panelListaDeseos = new JPanel();
        panelListaDeseos.setLayout(new BorderLayout());
        panelListaDeseos.setBackground(Color.WHITE);

        JLabel lblTitulo = new JLabel("Lista de Deseos", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));

        JList<String> listaDeseos = new JList<>(listaDeseosModel);
        JScrollPane scrollListaDeseos = new JScrollPane(listaDeseos);

        JButton btnVolver = new JButton("Volver al Catálogo");
        estilizarBoton(btnVolver, new Color(70, 130, 180)); // Azul

        btnVolver.addActionListener(e -> cardLayout.show(panelPrincipal, "Catalogo"));

        panelListaDeseos.add(lblTitulo, BorderLayout.NORTH);
        panelListaDeseos.add(scrollListaDeseos, BorderLayout.CENTER);
        panelListaDeseos.add(btnVolver, BorderLayout.SOUTH);

        panelPrincipal.add(panelListaDeseos, "ListaDeseos");
    }

    private void inicializarCambioContraseña() {
        panelCambioContraseña = new JPanel();
        panelCambioContraseña.setLayout(new GridBagLayout());
        panelCambioContraseña.setBackground(new Color(220, 230, 250)); // Fondo suave

        JLabel lblNuevaContraseña = new JLabel("Nueva Contraseña:");
        lblNuevaContraseña.setFont(new Font("Arial", Font.BOLD, 16));

        JPasswordField txtNuevaContrasena = new JPasswordField(15);

        JButton btnGuardarContraseña = new JButton("Guardar");
        btnGuardarContraseña.setFont(new Font("Arial", Font.BOLD, 14));
        btnGuardarContraseña.setBackground(new Color(60, 179, 113)); // Verde claro
        btnGuardarContraseña.setForeground(Color.WHITE);
        btnGuardarContraseña.setFocusPainted(false);

        btnGuardarContraseña.addActionListener(e -> {
            contraseñaGuardada = new String(txtNuevaContrasena.getPassword());
            JOptionPane.showMessageDialog(this, "Contraseña cambiada exitosamente.");
            cardLayout.show(panelPrincipal, "Login");
        });

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panelCambioContraseña.add(lblNuevaContraseña, gbc);

        gbc.gridx = 1;
        panelCambioContraseña.add(txtNuevaContrasena, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panelCambioContraseña.add(btnGuardarContraseña, gbc);

        panelPrincipal.add(panelCambioContraseña, "CambioContraseña");
    }

    private void estilizarBoton(JButton boton, Color color) {
        boton.setBackground(color);
        boton.setFont(new Font("Arial", Font.BOLD, 14));
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
    }

}