/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.login;

/**
 *
 * @author juan fabra
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaPrincipal extends JFrame {
    private JPanel panelPrincipal;
    private JPanel panelLogin, panelCatalogo, panelCarrito, panelListaDeseos;
    private CardLayout cardLayout;
    private DefaultListModel<String> carritoModel;
    private DefaultListModel<String> listaDeseosModel;

    public VentanaPrincipal() {
        setTitle("Tienda Virtual - Vendedores");
        setSize(900, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Inicializa el panel principal con CardLayout
        cardLayout = new CardLayout();
        panelPrincipal = new JPanel(cardLayout);
        getContentPane().add(panelPrincipal);

        carritoModel = new DefaultListModel<>();
        listaDeseosModel = new DefaultListModel<>();

        // Inicializa los diferentes paneles
        inicializarLogin();  // Panel Login
        inicializarCatalogo();  // Panel Catálogo
        inicializarCarrito();  // Panel Carrito
        inicializarListaDeseos();  // Panel Lista de Deseos

        setVisible(true);
    }

    private void inicializarLogin() {
        panelLogin = new JPanel();
        panelLogin.setLayout(new GridBagLayout());
        panelLogin.setBackground(Color.LIGHT_GRAY);

        JLabel lblUsuario = new JLabel("Usuario:");
        JTextField txtUsuario = new JTextField(15);
        JLabel lblContrasena = new JLabel("Contraseña:");
        JPasswordField txtContrasena = new JPasswordField(15);
        JButton btnLogin = new JButton("Iniciar Sesión");

        btnLogin.addActionListener(e -> cardLayout.show(panelPrincipal, "Catalogo"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panelLogin.add(lblUsuario, gbc);
        gbc.gridx = 1;
        panelLogin.add(txtUsuario, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panelLogin.add(lblContrasena, gbc);
        gbc.gridx = 1;
        panelLogin.add(txtContrasena, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panelLogin.add(btnLogin, gbc);

        panelPrincipal.add(panelLogin, "Login");
    }

    private void inicializarCatalogo() {
        panelCatalogo = new JPanel();
        panelCatalogo.setLayout(new BorderLayout());
        panelCatalogo.setBackground(Color.WHITE);

        JLabel lblTitulo = new JLabel("Catálogo de Productos", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        lblTitulo.setForeground(Color.BLUE);

        JPanel panelProductos = new JPanel();
        panelProductos.setLayout(new GridLayout(3, 3, 10, 10));
        panelProductos.setBackground(Color.WHITE);

        String[][] productos = {
            {"Manzana", "Deliciosa manzana roja"},
            {"Pera", "Jugosa y dulce"},
            {"Jugo de naranja", "Natural y fresco"},
            {"Pan", "Esponjoso y recién horneado"},
            {"Leche", "Fresca y pasteurizada"},
            {"Café", "De grano colombiano"},
            {"Queso", "Suave y cremoso"}
        };

        for (String[] producto : productos) {
            JButton btnProducto = new JButton("<html><b>" + producto[0] + "</b><br>" + producto[1] + "</html>");
            btnProducto.addActionListener(e -> mostrarOpcionesProducto(producto[0]));
            panelProductos.add(btnProducto);
        }

        JButton btnCarrito = new JButton("Ir al Carrito");
        btnCarrito.addActionListener(e -> cardLayout.show(panelPrincipal, "Carrito"));

        JButton btnListaDeseos = new JButton("Ir a Lista de Deseos");
        btnListaDeseos.addActionListener(e -> cardLayout.show(panelPrincipal, "ListaDeseos"));

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnCarrito);
        panelBotones.add(btnListaDeseos);

        panelCatalogo.add(lblTitulo, BorderLayout.NORTH);
        panelCatalogo.add(panelProductos, BorderLayout.CENTER);
        panelCatalogo.add(panelBotones, BorderLayout.SOUTH);

        panelPrincipal.add(panelCatalogo, "Catalogo");
    }

    private void mostrarOpcionesProducto(String producto) {
        int opcion = JOptionPane.showOptionDialog(
            this,
            "¿Qué desea hacer con " + producto + "?",
            "Opciones de Producto",
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            new String[]{"Agregar al Carrito", "Agregar a Lista de Deseos", "Cancelar"},
            "Cancelar"
        );

        switch (opcion) {
            case 0 -> carritoModel.addElement(producto);
            case 1 -> listaDeseosModel.addElement(producto);
            default -> {
            }
        }
    }

    private void inicializarCarrito() {
        panelCarrito = new JPanel();
        panelCarrito.setLayout(new BorderLayout());
        panelCarrito.setBackground(Color.WHITE);

        JLabel lblTitulo = new JLabel("Carrito de Compras", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        lblTitulo.setForeground(Color.RED);

        JList<String> listaCarrito = new JList<>(carritoModel);
        JScrollPane scrollCarrito = new JScrollPane(listaCarrito);

        JButton btnFinalizarCompra = new JButton("Finalizar Compra");
        btnFinalizarCompra.addActionListener(e -> {
            if (!carritoModel.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Compra realizada. Llegará en 2 días.");
                carritoModel.clear();
            } else {
                JOptionPane.showMessageDialog(this, "El carrito está vacío.");
            }
        });

        JButton btnVolver = new JButton("Volver al Catálogo");
        btnVolver.addActionListener(e -> cardLayout.show(panelPrincipal, "Catalogo"));

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnFinalizarCompra);
        panelBotones.add(btnVolver);

        panelCarrito.add(lblTitulo, BorderLayout.NORTH);
        panelCarrito.add(scrollCarrito, BorderLayout.CENTER);
        panelCarrito.add(panelBotones, BorderLayout.SOUTH);

        panelPrincipal.add(panelCarrito, "Carrito");
    }

    private void inicializarListaDeseos() {
        panelListaDeseos = new JPanel();
        panelListaDeseos.setLayout(new BorderLayout());
        panelListaDeseos.setBackground(Color.PINK);

        JLabel lblTitulo = new JLabel("Lista de Deseos", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        lblTitulo.setForeground(Color.MAGENTA);

        JList<String> listaDeseos = new JList<>(listaDeseosModel);
        JScrollPane scrollDeseos = new JScrollPane(listaDeseos);

        JButton btnMoverCarrito = new JButton("Mover al Carrito");
        btnMoverCarrito.addActionListener(e -> {
            for (String item : listaDeseos.getSelectedValuesList()) {
                carritoModel.addElement(item);
                listaDeseosModel.removeElement(item);
            }
        });

        JButton btnVolver = new JButton("Volver al Catálogo");
        btnVolver.addActionListener(e -> cardLayout.show(panelPrincipal, "Catalogo"));

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnMoverCarrito);
        panelBotones.add(btnVolver);

        panelListaDeseos.add(lblTitulo, BorderLayout.NORTH);
        panelListaDeseos.add(scrollDeseos, BorderLayout.CENTER);
        panelListaDeseos.add(panelBotones, BorderLayout.SOUTH);

        panelPrincipal.add(panelListaDeseos, "ListaDeseos");
    }

}