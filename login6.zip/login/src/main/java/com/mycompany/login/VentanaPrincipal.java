/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.login;

/**
 *
 * @author juan fabra
 */
import javax.swing.*;
import java.awt.*;

public class VentanaPrincipal extends JFrame {
    private JPanel panelPrincipal;
    private JPanel panelLogin, panelCatalogo, panelCarrito, panelListaDeseos, panelCambioContrasena;
    private CardLayout cardLayout;
    private DefaultListModel<String> carritoModel;
    private DefaultListModel<String> listaDeseosModel;

    // Variables para manejar el usuario y contraseña
    private String usuarioGuardado = "admin";
    private String contrasenaGuardada = "1234";

    public VentanaPrincipal() {
        setTitle("Tienda Virtual - Vendedores");
        setSize(900, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Inicializa el panel principal con CardLayout
        cardLayout = new CardLayout();
        panelPrincipal = new JPanel(cardLayout);
        getContentPane().add(panelPrincipal);

        // Inicialización de las listas de datos
        carritoModel = new DefaultListModel<>();
        listaDeseosModel = new DefaultListModel<>();

        // Inicializa los diferentes paneles
        inicializarLogin();        // Panel Login
        inicializarCatalogo();     // Panel Catálogo
        inicializarCarrito();      // Panel Carrito
        inicializarListaDeseos();  // Panel Lista de Deseos
        inicializarCambioContrasena(); // Panel Cambio Contraseña

        // Muestra el panel inicial
        cardLayout.show(panelPrincipal, "Login");

        setVisible(true);
    }

    private void inicializarLogin() {
        panelLogin = new JPanel();
        panelLogin.setLayout(new GridBagLayout());
        panelLogin.setBackground(new Color(220, 230, 250)); // Fondo suave

        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setFont(new Font("Arial", Font.BOLD, 16));

        JTextField txtUsuario = new JTextField(15);

        JLabel lblContrasena = new JLabel("Contraseña:");
        lblContrasena.setFont(new Font("Arial", Font.BOLD, 16));

        JPasswordField txtContrasena = new JPasswordField(15);

        JButton btnLogin = new JButton("Iniciar Sesión");
        JButton btnCambiarContrasena = new JButton("Cambiar Contraseña");

        estilizarBoton(btnLogin, new Color(60, 179, 113)); // Verde claro
        estilizarBoton(btnCambiarContrasena, new Color(255, 140, 0)); // Naranja

        // Acción del botón de login
        btnLogin.addActionListener(e -> {
            String usuario = txtUsuario.getText();
            String contrasena = new String(txtContrasena.getPassword());

            if (usuario.equals(usuarioGuardado) && contrasena.equals(contrasenaGuardada)) {
                cardLayout.show(panelPrincipal, "Catalogo");
            } else {
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Acción del botón para cambiar contraseña
        btnCambiarContrasena.addActionListener(e -> cardLayout.show(panelPrincipal, "CambioContrasena"));

        // Diseño del panel
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panelLogin.add(lblUsuario, gbc);
        gbc.gridx = 1;
        panelLogin.add(txtUsuario, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panelLogin.add(lblContrasena, gbc);
        gbc.gridx = 1;
        panelLogin.add(txtContrasena, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panelLogin.add(btnLogin, gbc);

        gbc.gridy = 3;
        panelLogin.add(btnCambiarContrasena, gbc);

        panelPrincipal.add(panelLogin, "Login");
    }

    private void inicializarCatalogo() {
        // Código del catálogo (sin cambios del anterior)
    }

    private void inicializarCarrito() {
        // Código del carrito (sin cambios del anterior)
    }

    private void inicializarListaDeseos() {
        // Código de lista de deseos (sin cambios del anterior)
    }

    private void inicializarCambioContrasena() {
        panelCambioContrasena = new JPanel();
        panelCambioContrasena.setLayout(new GridBagLayout());
        panelCambioContrasena.setBackground(new Color(255, 228, 225)); // Fondo rosa claro

        JLabel lblNuevaContrasena = new JLabel("Nueva Contraseña:");
        lblNuevaContrasena.setFont(new Font("Arial", Font.BOLD, 16));

        JPasswordField txtNuevaContrasena = new JPasswordField(15);

        JLabel lblConfirmarContrasena = new JLabel("Confirmar Contraseña:");
        lblConfirmarContrasena.setFont(new Font("Arial", Font.BOLD, 16));

        JPasswordField txtConfirmarContrasena = new JPasswordField(15);

        JButton btnGuardar = new JButton("Guardar Cambios");
        JButton btnCancelar = new JButton("Cancelar");

        estilizarBoton(btnGuardar, new Color(60, 179, 113)); // Verde claro
        estilizarBoton(btnCancelar, new Color(255, 69, 0)); // Rojo

        // Acción para guardar nueva contraseña
        btnGuardar.addActionListener(e -> {
            String nuevaContrasena = new String(txtNuevaContrasena.getPassword());
            String confirmarContrasena = new String(txtConfirmarContrasena.getPassword());

            if (nuevaContrasena.isEmpty() || confirmarContrasena.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (!nuevaContrasena.equals(confirmarContrasena)) {
                JOptionPane.showMessageDialog(this, "Las contraseñas no coinciden.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                contrasenaGuardada = nuevaContrasena;
                JOptionPane.showMessageDialog(this, "Contraseña cambiada con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                cardLayout.show(panelPrincipal, "Login");
            }
        });

        // Acción para cancelar
        btnCancelar.addActionListener(e -> cardLayout.show(panelPrincipal, "Login"));

        // Diseño del panel
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panelCambioContrasena.add(lblNuevaContrasena, gbc);
        gbc.gridx = 1;
        panelCambioContrasena.add(txtNuevaContrasena, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panelCambioContrasena.add(lblConfirmarContrasena, gbc);
        gbc.gridx = 1;
        panelCambioContrasena.add(txtConfirmarContrasena, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panelCambioContrasena.add(btnGuardar, gbc);

        gbc.gridy = 3;
        panelCambioContrasena.add(btnCancelar, gbc);

        panelPrincipal.add(panelCambioContrasena, "CambioContrasena");
    }

    private void estilizarBoton(JButton boton, Color color) {
        boton.setFont(new Font("Arial", Font.BOLD, 14));
        boton.setBackground(color);
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(VentanaPrincipal::new);
    }
}
