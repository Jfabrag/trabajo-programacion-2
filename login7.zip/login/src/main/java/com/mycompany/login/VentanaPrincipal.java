/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.login;

/**
 *
 * @author juan fabra
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class VentanaPrincipal extends JFrame {
    private JPanel panelPrincipal;
    private JPanel panelLogin, panelCatalogo, panelCarrito, panelListaDeseos, panelCambiarContrasena;
    private CardLayout cardLayout;
    private DefaultListModel<String> carritoModel;
    private DefaultListModel<String> listaDeseosModel;

    private String usuarioGuardado = "admin";
    private String contrasenaGuardada = "1234";

    public VentanaPrincipal() {
        setTitle("Tienda Virtual - Vendedores");
        setSize(900, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Inicializa el panel principal con CardLayout
        cardLayout = new CardLayout();
        panelPrincipal = new JPanel(cardLayout);
        getContentPane().add(panelPrincipal);

        carritoModel = new DefaultListModel<>();
        listaDeseosModel = new DefaultListModel<>();

        // Inicializa los diferentes paneles
        inicializarLogin();
        inicializarCatalogo();
        inicializarCarrito();
        inicializarListaDeseos();
        inicializarCambiarContrasena();

        setVisible(true);
    }

    private void inicializarLogin() {
        panelLogin = new JPanel();
        panelLogin.setLayout(new GridBagLayout());
        panelLogin.setBackground(new Color(220, 230, 250)); // Fondo suave

        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setFont(new Font("Arial", Font.BOLD, 16));
        JTextField txtUsuario = new JTextField(15);

        JLabel lblContrasena = new JLabel("Contraseña:");
        lblContrasena.setFont(new Font("Arial", Font.BOLD, 16));
        JPasswordField txtContrasena = new JPasswordField(15);

        JButton btnLogin = new JButton("Iniciar Sesión");
        btnLogin.setFont(new Font("Arial", Font.BOLD, 14));
        btnLogin.setBackground(new Color(60, 179, 113));
        btnLogin.setForeground(Color.WHITE);

        JButton btnCambiarContrasena = new JButton("¿Olvidaste tu contraseña?");
        btnCambiarContrasena.setFont(new Font("Arial", Font.PLAIN, 12));
        btnCambiarContrasena.setBackground(Color.WHITE);

        btnLogin.addActionListener(e -> {
            String usuario = txtUsuario.getText();
            String contrasena = new String(txtContrasena.getPassword());

            if (usuario.equals(usuarioGuardado) && contrasena.equals(contrasenaGuardada)) {
                cardLayout.show(panelPrincipal, "Catalogo");
            } else {
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnCambiarContrasena.addActionListener(e -> cardLayout.show(panelPrincipal, "CambiarContrasena"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panelLogin.add(lblUsuario, gbc);
        gbc.gridx = 1;
        panelLogin.add(txtUsuario, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panelLogin.add(lblContrasena, gbc);
        gbc.gridx = 1;
        panelLogin.add(txtContrasena, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        panelLogin.add(btnLogin, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        panelLogin.add(btnCambiarContrasena, gbc);

        panelPrincipal.add(panelLogin, "Login");
    }

    private void inicializarCatalogo() {
        panelCatalogo = new JPanel();
        panelCatalogo.setLayout(new BorderLayout());
        panelCatalogo.setBackground(Color.WHITE);

        JLabel lblTitulo = new JLabel("Catálogo de Productos", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));

        JButton btnVolverLogin = new JButton("Cerrar Sesión");
        btnVolverLogin.addActionListener(e -> cardLayout.show(panelPrincipal, "Login"));

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnVolverLogin);

        panelCatalogo.add(lblTitulo, BorderLayout.NORTH);
        panelCatalogo.add(panelBotones, BorderLayout.SOUTH);

        panelPrincipal.add(panelCatalogo, "Catalogo");
    }

    private void inicializarCarrito() {
        panelCarrito = new JPanel(new BorderLayout());
        panelCarrito.setBackground(Color.WHITE);

        JLabel lblTitulo = new JLabel("Carrito de Compras", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));

        JButton btnVolver = new JButton("Volver al Catálogo");
        btnVolver.addActionListener(e -> cardLayout.show(panelPrincipal, "Catalogo"));

        panelCarrito.add(lblTitulo, BorderLayout.NORTH);
        panelCarrito.add(btnVolver, BorderLayout.SOUTH);

        panelPrincipal.add(panelCarrito, "Carrito");
    }

    private void inicializarListaDeseos() {
        panelListaDeseos = new JPanel(new BorderLayout());
        panelListaDeseos.setBackground(new Color(245, 222, 179)); // Fondo beige

        JLabel lblTitulo = new JLabel("Lista de Deseos", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));

        JButton btnVolver = new JButton("Volver al Catálogo");
        btnVolver.addActionListener(e -> cardLayout.show(panelPrincipal, "Catalogo"));

        panelListaDeseos.add(lblTitulo, BorderLayout.NORTH);
        panelListaDeseos.add(btnVolver, BorderLayout.SOUTH);

        panelPrincipal.add(panelListaDeseos, "ListaDeseos");
    }

    private void inicializarCambiarContrasena() {
        panelCambiarContrasena = new JPanel(new GridBagLayout());
        panelCambiarContrasena.setBackground(new Color(240, 248, 255)); // Fondo azul claro

        JLabel lblNuevaContrasena = new JLabel("Nueva Contraseña:");
        lblNuevaContrasena.setFont(new Font("Arial", Font.BOLD, 16));
        JPasswordField txtNuevaContrasena = new JPasswordField(15);

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setFont(new Font("Arial", Font.BOLD, 14));
        btnGuardar.setBackground(new Color(60, 179, 113));
        btnGuardar.setForeground(Color.WHITE);

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.setFont(new Font("Arial", Font.PLAIN, 14));
        btnCancelar.setBackground(Color.WHITE);

        btnGuardar.addActionListener(e -> {
            contrasenaGuardada = new String(txtNuevaContrasena.getPassword());
            JOptionPane.showMessageDialog(this, "Contraseña actualizada correctamente");
            cardLayout.show(panelPrincipal, "Login");
        });

        btnCancelar.addActionListener(e -> cardLayout.show(panelPrincipal, "Login"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panelCambiarContrasena.add(lblNuevaContrasena, gbc);
        gbc.gridx = 1;
        panelCambiarContrasena.add(txtNuevaContrasena, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        panelCambiarContrasena.add(btnGuardar, gbc);

        gbc.gridy = 2;
        panelCambiarContrasena.add(btnCancelar, gbc);

        panelPrincipal.add(panelCambiarContrasena, "CambiarContrasena");
    }

}