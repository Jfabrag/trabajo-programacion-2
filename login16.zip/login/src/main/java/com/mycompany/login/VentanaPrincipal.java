/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.login;

/**
 *
 * @author juan fabra
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaPrincipal extends JFrame {
    private JPanel panelPrincipal;
    private JPanel panelLogin, panelCatalogo, panelCarrito, panelListaDeseos, panelCambioContraseña, panelHistorial;
    private CardLayout cardLayout;
    private DefaultListModel<String> carritoModel;
    private DefaultListModel<String> listaDeseosModel;
    private DefaultListModel<String> historialModel;

    private String contraseñaGuardada = "1234";
    private String nombreUsuario = "";

    // Corregimos la declaración de la variable lblBienvenida
    private JLabel lblBienvenida;

    public VentanaPrincipal() {
        setTitle("Tienda Virtual - Vendedores");
        setSize(900, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel principal con CardLayout
        cardLayout = new CardLayout();
        panelPrincipal = new JPanel(cardLayout);
        getContentPane().add(panelPrincipal);

        carritoModel = new DefaultListModel<>();
        listaDeseosModel = new DefaultListModel<>();
        historialModel = new DefaultListModel<>(); // Inicializamos el modelo para el historial de compras

        // Inicializa los paneles
        inicializarLogin();
        inicializarCatalogo();
        inicializarCarrito();
        inicializarListaDeseos();
        inicializarCambioContraseña();
        inicializarHistorial(); // Inicializamos el panel de historial

        setVisible(true);
    }

    private void inicializarLogin() {
        panelLogin = new JPanel();
        panelLogin.setLayout(new GridBagLayout());
        panelLogin.setBackground(new Color(220, 230, 250));

        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setFont(new Font("Arial", Font.BOLD, 16));

        JTextField txtUsuario = new JTextField(15);

        JLabel lblContrasena = new JLabel("Contraseña:");
        lblContrasena.setFont(new Font("Arial", Font.BOLD, 16));

        JPasswordField txtContrasena = new JPasswordField(15);

        JButton btnLogin = new JButton("Iniciar Sesión");
        JButton btnCambiarContrasena = new JButton("Olvidé mi contraseña");

        btnLogin.addActionListener(e -> {
            String passwordInput = new String(txtContrasena.getPassword());
            if (passwordInput.equals(contraseñaGuardada)) {
                nombreUsuario = txtUsuario.getText().trim();
                if (!nombreUsuario.isEmpty()) {
                    setTitle("Bienvenido, " + nombreUsuario + " - Tienda Virtual");
                }
                actualizarBienvenida();
                cardLayout.show(panelPrincipal, "Catalogo");
            } else {
                JOptionPane.showMessageDialog(this, "Contraseña incorrecta, intente nuevamente.");
            }
        });

        btnCambiarContrasena.addActionListener(e -> cardLayout.show(panelPrincipal, "CambioContraseña"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panelLogin.add(lblUsuario, gbc);
        gbc.gridx = 1;
        panelLogin.add(txtUsuario, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panelLogin.add(lblContrasena, gbc);
        gbc.gridx = 1;
        panelLogin.add(txtContrasena, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        panelLogin.add(btnLogin, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panelLogin.add(btnCambiarContrasena, gbc);

        panelPrincipal.add(panelLogin, "Login");
    }

    private void inicializarCatalogo() {
        panelCatalogo = new JPanel();
        panelCatalogo.setLayout(new BorderLayout());
        panelCatalogo.setBackground(Color.WHITE);

        lblBienvenida = new JLabel("", JLabel.CENTER); // Inicializamos la variable lblBienvenida
        lblBienvenida.setFont(new Font("Arial", Font.BOLD, 18));

        JLabel lblTitulo = new JLabel("Catálogo de Productos", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));

        JPanel panelProductos = new JPanel();
        panelProductos.setLayout(new GridLayout(3, 3, 15, 15));
        panelProductos.setBackground(Color.WHITE);

        String[][] productos = {
            {"Manzana", "Deliciosa manzana roja", "$2.00"},
            {"Pera", "Jugosa y dulce", "$2.50"},
            {"Jugo de naranja", "Natural y fresco", "$1.80"},
            {"Pan", "Esponjoso y recién horneado", "$1.00"},
            {"Leche", "Fresca y pasteurizada", "$1.50"},
            {"Café", "De grano colombiano", "$3.00"},
            {"Queso", "Suave y cremoso", "$2.70"},
            {"Té Verde", "Refrescante y antioxidante", "$1.60"}
        };

        for (String[] producto : productos) {
            JButton btnProducto = new JButton("<html><b>" + producto[0] + "</b><br>" + producto[1] + "<br><i>" + producto[2] + "</i></html>");
            btnProducto.setFont(new Font("Arial", Font.PLAIN, 14));
            btnProducto.setBackground(new Color(245, 245, 245));
            btnProducto.setBorder(BorderFactory.createLineBorder(new Color(70, 130, 180), 2));
            btnProducto.addActionListener(e -> mostrarOpcionesProducto(producto[0], producto[2]));
            panelProductos.add(btnProducto);
        }

        JButton btnCarrito = new JButton("Ir al Carrito");
        JButton btnListaDeseos = new JButton("Ir a Lista de Deseos");
        JButton btnHistorial = new JButton("Historial de Compras"); // Botón para acceder al historial

        btnCarrito.addActionListener(e -> cardLayout.show(panelPrincipal, "Carrito"));
        btnListaDeseos.addActionListener(e -> cardLayout.show(panelPrincipal, "ListaDeseos"));
        btnHistorial.addActionListener(e -> cardLayout.show(panelPrincipal, "Historial"));

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnCarrito);
        panelBotones.add(btnListaDeseos);
        panelBotones.add(btnHistorial); // Añadimos el botón al panel de botones

        panelCatalogo.add(lblBienvenida, BorderLayout.NORTH);
        panelCatalogo.add(panelProductos, BorderLayout.CENTER);
        panelCatalogo.add(panelBotones, BorderLayout.SOUTH);

        panelPrincipal.add(panelCatalogo, "Catalogo");
    }

    private void actualizarBienvenida() {
        lblBienvenida.setText("¡Bienvenido(a), " + nombreUsuario + "! Explora nuestros productos.");
    }

    private void mostrarOpcionesProducto(String nombre, String precio) {
        int opcion = JOptionPane.showOptionDialog(this, "Selecciona una acción para " + nombre + " (" + precio + ")",
                "Opciones de Producto", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null,
                new String[]{"Añadir al carrito", "Añadir a lista de deseos", "Comprar", "Cancelar"}, "Cancelar");

        if (opcion == 0) {
            carritoModel.addElement(nombre + " - " + precio);
            JOptionPane.showMessageDialog(this, nombre + " se ha añadido al carrito.");
        } else if (opcion == 1) {
            listaDeseosModel.addElement(nombre + " - " + precio);
            JOptionPane.showMessageDialog(this, nombre + " se ha añadido a la lista de deseos.");
        } else if (opcion == 2) {
            historialModel.addElement(nombre + " - " + precio); // Agregamos al historial de compras
            JOptionPane.showMessageDialog(this, "¡Compra realizada! " + nombre + " se ha añadido a tu historial.");
        }
    }

    private void inicializarCarrito() {
        panelCarrito = new JPanel(new BorderLayout());
        JLabel lblTitulo = new JLabel("Carrito de Compras", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));

        JList<String> listaCarrito = new JList<>(carritoModel);
        JScrollPane scrollCarrito = new JScrollPane(listaCarrito);

        JButton btnEliminar = new JButton("Eliminar Seleccionado");
        btnEliminar.addActionListener(e -> {
            int seleccion = listaCarrito.getSelectedIndex();
            if (seleccion != -1) {
                carritoModel.remove(seleccion);
                JOptionPane.showMessageDialog(this, "Producto eliminado del carrito.");
            } else {
                JOptionPane.showMessageDialog(this, "Seleccione un producto para eliminar.");
            }
        });

        JButton btnVolver = new JButton("Volver al Catálogo");
        btnVolver.addActionListener(e -> cardLayout.show(panelPrincipal, "Catalogo"));

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnEliminar);
        panelBotones.add(btnVolver);

        panelCarrito.add(lblTitulo, BorderLayout.NORTH);
        panelCarrito.add(scrollCarrito, BorderLayout.CENTER);
        panelCarrito.add(panelBotones, BorderLayout.SOUTH);

        panelPrincipal.add(panelCarrito, "Carrito");
    }

    private void inicializarListaDeseos() {
        panelListaDeseos = new JPanel(new BorderLayout());
        JLabel lblTitulo = new JLabel("Lista de Deseos", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));

        JList<String> listaDeseos = new JList<>(listaDeseosModel);
        JScrollPane scrollListaDeseos = new JScrollPane(listaDeseos);

        JButton btnVolver = new JButton("Volver al Catálogo");
        btnVolver.addActionListener(e -> cardLayout.show(panelPrincipal, "Catalogo"));

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnVolver);

        panelListaDeseos.add(lblTitulo, BorderLayout.NORTH);
        panelListaDeseos.add(scrollListaDeseos, BorderLayout.CENTER);
        panelListaDeseos.add(panelBotones, BorderLayout.SOUTH);

        panelPrincipal.add(panelListaDeseos, "ListaDeseos");
    }

    private void inicializarCambioContraseña() {
        panelCambioContraseña = new JPanel();
        panelCambioContraseña.setLayout(new GridBagLayout());
        panelCambioContraseña.setBackground(new Color(220, 230, 250));

        JLabel lblNuevaContraseña = new JLabel("Nueva Contraseña:");
        lblNuevaContraseña.setFont(new Font("Arial", Font.BOLD, 16));

        JPasswordField txtNuevaContraseña = new JPasswordField(15);

        JButton btnGuardar = new JButton("Guardar Nueva Contraseña");
        btnGuardar.addActionListener(e -> {
            contraseñaGuardada = new String(txtNuevaContraseña.getPassword());
            JOptionPane.showMessageDialog(this, "Contraseña cambiada con éxito.");
            cardLayout.show(panelPrincipal, "Login");
        });

        JButton btnVolver = new JButton("Volver al Login");
        btnVolver.addActionListener(e -> cardLayout.show(panelPrincipal, "Login"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panelCambioContraseña.add(lblNuevaContraseña, gbc);

        gbc.gridx = 1;
        panelCambioContraseña.add(txtNuevaContraseña, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        panelCambioContraseña.add(btnGuardar, gbc);

        gbc.gridy = 2;
        panelCambioContraseña.add(btnVolver, gbc);

        panelPrincipal.add(panelCambioContraseña, "CambioContraseña");
    }

    private void inicializarHistorial() {
        panelHistorial = new JPanel(new BorderLayout());
        JLabel lblTitulo = new JLabel("Historial de Compras", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));

        JList<String> listaHistorial = new JList<>(historialModel);
        JScrollPane scrollHistorial = new JScrollPane(listaHistorial);

        JButton btnVolver = new JButton("Volver al Catálogo");
        btnVolver.addActionListener(e -> cardLayout.show(panelPrincipal, "Catalogo"));

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnVolver);

        panelHistorial.add(lblTitulo, BorderLayout.NORTH);
        panelHistorial.add(scrollHistorial, BorderLayout.CENTER);
        panelHistorial.add(panelBotones, BorderLayout.SOUTH);

        panelPrincipal.add(panelHistorial, "Historial");
    }

}