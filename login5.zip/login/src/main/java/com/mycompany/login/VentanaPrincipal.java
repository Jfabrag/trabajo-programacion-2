/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.login;

/**
 *
 * @author juan fabra
 */
import javax.swing.*;
import java.awt.*;

public class VentanaPrincipal extends JFrame {
    private JPanel panelPrincipal;
    private JPanel panelLogin, panelCatalogo, panelCarrito, panelListaDeseos;
    private CardLayout cardLayout;
    private DefaultListModel<String> carritoModel;
    private DefaultListModel<String> listaDeseosModel;

    public VentanaPrincipal() {
        setTitle("Tienda Virtual - Vendedores");
        setSize(900, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Inicializa el panel principal con CardLayout
        cardLayout = new CardLayout();
        panelPrincipal = new JPanel(cardLayout);
        getContentPane().add(panelPrincipal);

        // Inicialización de las listas de datos
        carritoModel = new DefaultListModel<>();
        listaDeseosModel = new DefaultListModel<>();

        // Inicializa los diferentes paneles
        inicializarLogin();        // Panel Login
        inicializarCatalogo();     // Panel Catálogo
        inicializarCarrito();      // Panel Carrito
        inicializarListaDeseos();  // Panel Lista de Deseos

        // Muestra el panel inicial
        cardLayout.show(panelPrincipal, "Login");

        setVisible(true);
    }

    private void inicializarLogin() {
        panelLogin = new JPanel();
        panelLogin.setLayout(new GridBagLayout());
        panelLogin.setBackground(new Color(220, 230, 250)); // Fondo suave

        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setFont(new Font("Arial", Font.BOLD, 16));

        JTextField txtUsuario = new JTextField(15);

        JLabel lblContrasena = new JLabel("Contraseña:");
        lblContrasena.setFont(new Font("Arial", Font.BOLD, 16));

        JPasswordField txtContrasena = new JPasswordField(15);

        JButton btnLogin = new JButton("Iniciar Sesión");
        btnLogin.setFont(new Font("Arial", Font.BOLD, 14));
        btnLogin.setBackground(new Color(60, 179, 113)); // Verde claro
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);

        // Acción del botón de login
        btnLogin.addActionListener(e -> {
            String usuario = txtUsuario.getText();
            String contrasena = new String(txtContrasena.getPassword());

            if ("admin".equals(usuario) && "1234".equals(contrasena)) {
                cardLayout.show(panelPrincipal, "Catalogo");
            } else {
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Diseño del panel
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panelLogin.add(lblUsuario, gbc);
        gbc.gridx = 1;
        panelLogin.add(txtUsuario, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panelLogin.add(lblContrasena, gbc);
        gbc.gridx = 1;
        panelLogin.add(txtContrasena, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panelLogin.add(btnLogin, gbc);

        panelPrincipal.add(panelLogin, "Login");
    }

    private void inicializarCatalogo() {
        panelCatalogo = new JPanel();
        panelCatalogo.setLayout(new BorderLayout());
        panelCatalogo.setBackground(Color.WHITE);

        JLabel lblTitulo = new JLabel("Catálogo de Productos", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        lblTitulo.setForeground(new Color(70, 130, 180)); // Azul suave

        JPanel panelProductos = new JPanel();
        panelProductos.setLayout(new GridLayout(3, 3, 15, 15));
        panelProductos.setBackground(Color.WHITE);

        String[][] productos = {
            {"Manzana", "Deliciosa manzana roja"},
            {"Pera", "Jugosa y dulce"},
            {"Jugo de naranja", "Natural y fresco"},
            {"Pan", "Esponjoso y recién horneado"},
            {"Leche", "Fresca y pasteurizada"},
            {"Café", "De grano colombiano"},
            {"Queso", "Suave y cremoso"},
            {"Té Verde", "Refrescante y antioxidante"}
        };

        for (String[] producto : productos) {
            JButton btnProducto = new JButton("<html><b>" + producto[0] + "</b><br>" + producto[1] + "</html>");
            btnProducto.setFont(new Font("Arial", Font.PLAIN, 14));
            btnProducto.setBackground(new Color(245, 245, 245)); // Gris claro
            btnProducto.setBorder(BorderFactory.createLineBorder(new Color(70, 130, 180), 2));
            btnProducto.addActionListener(e -> mostrarOpcionesProducto(producto[0]));
            panelProductos.add(btnProducto);
        }

        JButton btnCarrito = new JButton("Ir al Carrito");
        JButton btnListaDeseos = new JButton("Ir a Lista de Deseos");

        estilizarBoton(btnCarrito, new Color(46, 139, 87)); // Verde oscuro
        estilizarBoton(btnListaDeseos, new Color(123, 104, 238)); // Morado suave

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnCarrito);
        panelBotones.add(btnListaDeseos);

        btnCarrito.addActionListener(e -> cardLayout.show(panelPrincipal, "Carrito"));
        btnListaDeseos.addActionListener(e -> cardLayout.show(panelPrincipal, "ListaDeseos"));

        panelCatalogo.add(lblTitulo, BorderLayout.NORTH);
        panelCatalogo.add(panelProductos, BorderLayout.CENTER);
        panelCatalogo.add(panelBotones, BorderLayout.SOUTH);

        panelPrincipal.add(panelCatalogo, "Catalogo");
    }

    private void mostrarOpcionesProducto(String producto) {
        int opcion = JOptionPane.showOptionDialog(
            this,
            "¿Qué desea hacer con " + producto + "?",
            "Opciones de Producto",
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            new String[]{"Agregar al Carrito", "Agregar a Lista de Deseos", "Cancelar"},
            "Cancelar"
        );

        switch (opcion) {
            case 0 -> carritoModel.addElement(producto);
            case 1 -> listaDeseosModel.addElement(producto);
        }
    }

    private void inicializarCarrito() {
        // Implementación aquí
    }

    private void inicializarListaDeseos() {
        // Implementación aquí
    }

    private void estilizarBoton(JButton boton, Color color) {
        boton.setFont(new Font("Arial", Font.BOLD, 14));
        boton.setBackground(color);
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(VentanaPrincipal::new);
    }
}
