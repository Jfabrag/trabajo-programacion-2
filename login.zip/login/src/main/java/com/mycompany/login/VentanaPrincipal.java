/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.login;

/**
 *
 * @author juan fabra
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class VentanaPrincipal extends JFrame {
    private ArrayList<Producto> carrito;
    private ListaDeseos listaDeseos;
    private JPanel panelPrincipal;
    private JPanel panelCarrito;
    private JPanel panelListaDeseos;
    private CardLayout cardLayout;

    public VentanaPrincipal() {
        carrito = new ArrayList<>();
        listaDeseos = new ListaDeseos();

        setTitle("Aplicación de Compras");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        cardLayout = new CardLayout();
        setLayout(cardLayout);

        // Crear paneles
        JPanel panelInicioSesion = crearPanelInicioSesion();
        panelPrincipal = crearPanelPrincipal();
        panelCarrito = crearPanelCarrito();
        panelListaDeseos = crearPanelListaDeseos();

        // Agregar paneles al CardLayout
        add(panelInicioSesion, "inicioSesion");
        add(panelPrincipal, "principal");
        add(panelCarrito, "carrito");
        add(panelListaDeseos, "listaDeseos");

        // Mostrar el panel de inicio de sesión al iniciar
        cardLayout.show(getContentPane(), "inicioSesion");
    }

    private JPanel crearPanelInicioSesion() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2, 10, 10));

        JLabel lblUsuario = new JLabel("Usuario:");
        JTextField txtUsuario = new JTextField();

        JLabel lblContraseña = new JLabel("Contraseña:");
        JPasswordField txtContraseña = new JPasswordField();

        JButton btnIniciarSesion = new JButton("Iniciar Sesión");
        btnIniciarSesion.addActionListener(e -> {
            String usuario = txtUsuario.getText();
            String contraseña = new String(txtContraseña.getPassword());

            if ("admin".equals(usuario) && "1234".equals(contraseña)) {
                JOptionPane.showMessageDialog(this, "Inicio de sesión exitoso.");
                cardLayout.show(getContentPane(), "principal");
            } else {
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos.");
            }
        });

        JButton btnSalir = new JButton("Salir");
        btnSalir.addActionListener(e -> System.exit(0));

        panel.add(lblUsuario);
        panel.add(txtUsuario);
        panel.add(lblContraseña);
        panel.add(txtContraseña);
        panel.add(btnIniciarSesion);
        panel.add(btnSalir);

        return panel;
    }

    private JPanel crearPanelPrincipal() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        JLabel lblTitulo = new JLabel("Bienvenido a la Tienda", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        panel.add(lblTitulo, BorderLayout.NORTH);

        JPanel panelProductos = new JPanel(new GridLayout(2, 2, 10, 10));
        Producto manzana = new Producto("Manzana", "Fruta fresca", 3000);
        Producto leche = new Producto("Leche", "Leche entera", 5000);
        Producto pan = new Producto("Pan", "Pan artesanal", 2500);
        Producto cafe = new Producto("Café", "Café premium", 8000);

        agregarProducto(panelProductos, manzana);
        agregarProducto(panelProductos, leche);
        agregarProducto(panelProductos, pan);
        agregarProducto(panelProductos, cafe);

        panel.add(panelProductos, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        JButton btnVerCarrito = new JButton("Ver Carrito");
        btnVerCarrito.addActionListener(e -> {
            actualizarCarrito();
            cardLayout.show(getContentPane(), "carrito");
        });
        JButton btnVerListaDeseos = new JButton("Ver Lista de Deseos");
        btnVerListaDeseos.addActionListener(e -> {
            actualizarListaDeseos();
            cardLayout.show(getContentPane(), "listaDeseos");
        });
        panelBotones.add(btnVerCarrito);
        panelBotones.add(btnVerListaDeseos);

        panel.add(panelBotones, BorderLayout.SOUTH);

        return panel;
    }

    private void agregarProducto(JPanel panel, Producto producto) {
        JPanel panelProducto = new JPanel(new BorderLayout());
        panelProducto.setBorder(BorderFactory.createTitledBorder(producto.getNombre()));

        JLabel lblDescripcion = new JLabel(producto.getDescripcion() + " - $" + producto.getPrecio());
        JButton btnAgregarCarrito = new JButton("Al Carrito");
        btnAgregarCarrito.addActionListener(e -> {
            carrito.add(producto);
            JOptionPane.showMessageDialog(this, producto.getNombre() + " agregado al carrito.");
        });
        JButton btnAgregarListaDeseos = new JButton("A Lista de Deseos");
        btnAgregarListaDeseos.addActionListener(e -> {
            listaDeseos.agregarProducto(producto);
            JOptionPane.showMessageDialog(this, producto.getNombre() + " agregado a la lista de deseos.");
        });

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnAgregarCarrito);
        panelBotones.add(btnAgregarListaDeseos);

        panelProducto.add(lblDescripcion, BorderLayout.CENTER);
        panelProducto.add(panelBotones, BorderLayout.SOUTH);

        panel.add(panelProducto);
    }

    private JPanel crearPanelCarrito() {
        JPanel panel = new JPanel(new BorderLayout());
        JLabel lblTitulo = new JLabel("Carrito de Compras", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        panel.add(lblTitulo, BorderLayout.NORTH);

        JPanel panelProductos = new JPanel(new GridLayout(0, 1));
        for (Producto producto : carrito) {
            JLabel lblProducto = new JLabel(producto.getNombre() + " - $" + producto.getPrecio());
            panelProductos.add(lblProducto);
        }
        JScrollPane scrollPane = new JScrollPane(panelProductos);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        JButton btnVolver = new JButton("Volver");
        btnVolver.addActionListener(e -> cardLayout.show(getContentPane(), "principal"));
        panelBotones.add(btnVolver);

        panel.add(panelBotones, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel crearPanelListaDeseos() {
        JPanel panel = new JPanel(new BorderLayout());
        JLabel lblTitulo = new JLabel("Lista de Deseos", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        panel.add(lblTitulo, BorderLayout.NORTH);

        JPanel panelProductos = new JPanel(new GridLayout(0, 1));
        for (Producto producto : listaDeseos.getProductos()) {
            JPanel panelProducto = new JPanel(new FlowLayout());
            JLabel lblProducto = new JLabel(producto.getNombre());

            JButton btnMoverCarrito = new JButton("Mover al Carrito");
            btnMoverCarrito.addActionListener(e -> {
                carrito.add(producto);
                listaDeseos.eliminarProducto(producto);
                actualizarCarrito();
                actualizarListaDeseos();
            });

            JButton btnEliminar = new JButton("Eliminar");
            btnEliminar.addActionListener(e -> {
                listaDeseos.eliminarProducto(producto);
                actualizarListaDeseos();
            });

            panelProducto.add(lblProducto);
            panelProducto.add(btnMoverCarrito);
            panelProducto.add(btnEliminar);
            panelProductos.add(panelProducto);
        }

        JScrollPane scrollPane = new JScrollPane(panelProductos);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        JButton btnVolver = new JButton("Volver");
        btnVolver.addActionListener(e -> cardLayout.show(getContentPane(), "principal"));
        panelBotones.add(btnVolver);
        panel.add(panelBotones, BorderLayout.SOUTH);

        return panel;
    }

    private void actualizarCarrito() {
        panelCarrito.removeAll();
        JPanel panelProductos = new JPanel(new GridLayout(0, 1));
        for (Producto producto : carrito) {
            JLabel lblProducto = new JLabel(producto.getNombre() + " - $" + producto.getPrecio());
            panelProductos.add(lblProducto);
        }
        JScrollPane scrollPane = new JScrollPane(panelProductos);
        panelCarrito.add(scrollPane, BorderLayout.CENTER);
        panelCarrito.revalidate();
        panelCarrito.repaint();
    }

    private void actualizarListaDeseos() {
        panelListaDeseos.removeAll();
        JPanel panelProductos = new JPanel(new GridLayout(0, 1));
        for (Producto producto : listaDeseos.getProductos()) {
            JPanel panelProducto = new JPanel(new FlowLayout());
            JLabel lblProducto = new JLabel(producto.getNombre());

            JButton btnMoverCarrito = new JButton("Mover al Carrito");
            btnMoverCarrito.addActionListener(e -> {
                carrito.add(producto);
                listaDeseos.eliminarProducto(producto);
                actualizarCarrito();
                actualizarListaDeseos();
            });

            JButton btnEliminar = new JButton("Eliminar");
            btnEliminar.addActionListener(e -> {
                listaDeseos.eliminarProducto(producto);
                actualizarListaDeseos();
            });

            panelProducto.add(lblProducto);
            panelProducto.add(btnMoverCarrito);
            panelProducto.add(btnEliminar);
            panelProductos.add(panelProducto);
        }

        JScrollPane scrollPane = new JScrollPane(panelProductos);
        panelListaDeseos.add(scrollPane, BorderLayout.CENTER);
        panelListaDeseos.revalidate();
        panelListaDeseos.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VentanaPrincipal ventana = new VentanaPrincipal();
            ventana.setVisible(true);
        });
    }
}
