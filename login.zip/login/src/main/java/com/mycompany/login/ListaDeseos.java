/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.login;

/**
 *
 * @author juan fabra
 */
import java.util.ArrayList;
import java.util.List;

public class ListaDeseos {
    private List<Producto> listaDeseos;

    public ListaDeseos() {
        listaDeseos = new ArrayList<>();
    }

    public void agregarProducto(Producto producto) {
        listaDeseos.add(producto);
    }

    public boolean estaEnLista(Producto producto) {
        return listaDeseos.contains(producto);
    }

    public void eliminarProducto(Producto producto) {
        listaDeseos.remove(producto);
    }

    public List<Producto> getProductos() {
        return listaDeseos;
    }

    @Override
    public String toString() {
        if (listaDeseos.isEmpty()) {
            return "La lista de deseos está vacía.";
        }
        StringBuilder sb = new StringBuilder("Lista de Deseos:\n");
        for (Producto producto : listaDeseos) {
            sb.append("- ").append(producto.getNombre()).append(" ($").append(producto.getPrecio()).append(")\n");
        }
        return sb.toString();
    }

}
